#!/usr/bin/env python3
"""Source-linked precision validator for the completed full-topology export.

The exporter creates several quantities in CUDA/PyTorch float32 and casts them
to float64 only for storage. V4 keeps strict hashes, shapes, dtypes,
finiteness, topology, and accounting checks. For the protected decomposition,
it reconstructs the two rank-one projectors and the perpendicular precoder
from the raw nominal precoder and exported steering vectors in complex128,
then validates every exported component against the raw channel using
propagated float32 forward-error bounds. The direct component-sum residual is
accepted only when it is explained by those independently computed bounds.
All diagnostics are written before any numerical rejection.
"""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

PACKAGE = Path(sys.argv[1]).resolve()
OUTPUT = PACKAGE / "output"
RECOVERY = Path(sys.argv[2]).resolve()
RECOVERY.mkdir(parents=True, exist_ok=True)

FLOAT32_EPS = float(np.finfo(np.float32).eps)
FLOAT32_U = FLOAT32_EPS / 2.0
FLOAT32_TINY = float(np.finfo(np.float32).tiny)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def finite_memmap(value: np.ndarray, first_axis_chunk: int = 1) -> bool:
    if value.ndim == 0:
        return bool(np.isfinite(value))
    for start in range(0, value.shape[0], first_axis_chunk):
        stop = min(start + first_axis_chunk, value.shape[0])
        if not np.all(np.isfinite(np.asarray(value[start:stop]))):
            return False
    return True


def max_abs(value: np.ndarray) -> float:
    return float(np.max(np.abs(value))) if value.size else 0.0


def max_relative(
    actual: np.ndarray,
    expected: np.ndarray,
    floor: float,
) -> float:
    return float(
        np.max(
            np.abs(actual - expected)
            / np.maximum(np.abs(expected), floor)
        )
    )


def gamma_n(term_count: int) -> float:
    value = term_count * FLOAT32_U
    if value >= 1.0:
        raise ValueError("Invalid float32 reduction term count")
    return value / (1.0 - value)


def float32_ulp_distance(
    actual: np.ndarray,
    expected: np.ndarray,
) -> int:
    a = np.asarray(actual, dtype=np.float32)
    b = np.asarray(expected, dtype=np.float32)
    if np.any(a < 0) or np.any(b < 0):
        raise ValueError("ULP helper requires nonnegative arrays")
    ai = a.view(np.uint32).astype(np.int64)
    bi = b.view(np.uint32).astype(np.int64)
    return int(np.max(np.abs(ai - bi))) if a.size else 0


checks: dict[str, dict[str, object]] = {}
failures: list[str] = []


def record(name: str, passed: bool, **details: object) -> None:
    checks[name] = {"pass": bool(passed), **details}
    if not passed:
        failures.append(name)


def require_structural(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


for name in [
    "FULL_TOPOLOGY_EXPORT_AUDIT.json",
    "FULL_TOPOLOGY_EXPORT_ENVIRONMENT.json",
    "FULL_VS_CHUNKED_COMPARISON.json",
    "OUTPUT_ARRAY_MANIFEST.json",
    "USER_TOPOLOGY.csv",
    "SECTOR_TOPOLOGY.csv",
]:
    require_structural(
        (OUTPUT / name).is_file(),
        f"Missing output file: {name}",
    )

audit = json.loads(
    (OUTPUT / "FULL_TOPOLOGY_EXPORT_AUDIT.json").read_text(
        encoding="utf-8"
    )
)
manifest = json.loads(
    (OUTPUT / "OUTPUT_ARRAY_MANIFEST.json").read_text(
        encoding="utf-8"
    )
)
comparison = json.loads(
    (OUTPUT / "FULL_VS_CHUNKED_COMPARISON.json").read_text(
        encoding="utf-8"
    )
)

require_structural(
    audit["status"]
    == "PASS_CONTROLLER_READY_FULL_TOPOLOGY_EXPORT_REVIEW_REQUIRED",
    "Export audit status did not pass",
)
require_structural(
    comparison["legacy_numeric_reproduction"]["pass"] is True,
    "Legacy job-18658301 reproduction did not pass",
)
require_structural(
    audit["full_topology"]["mode"]
    == "one_topology_call_all_228_users",
    "Hidden topology fallback detected",
)
require_structural(
    audit["full_topology"]["response_shape"] == [228, 57, 128, 9],
    "Full-topology response shape is wrong",
)
require_structural(
    audit["full_topology"]["coefficient_shape"][1] == 228,
    "Full topology did not contain 228 users",
)

arrays: dict[str, np.ndarray] = {}
for name, metadata in manifest["arrays"].items():
    path = OUTPUT / name
    require_structural(path.is_file(), f"Missing array: {name}")
    require_structural(
        sha256_file(path) == metadata["sha256"],
        f"Array SHA-256 mismatch: {name}",
    )
    value = np.load(path, allow_pickle=False, mmap_mode="r")
    require_structural(
        list(value.shape) == metadata["shape"],
        f"Shape mismatch: {name}",
    )
    require_structural(
        str(value.dtype) == metadata["dtype"],
        f"Dtype mismatch: {name}",
    )
    require_structural(
        finite_memmap(value),
        f"Non-finite values: {name}",
    )
    arrays[name] = value

expected_shapes = {
    "frequency_response.npy": (9, 228, 57, 128),
    "serving_bs_index.npy": (228,),
    "serving_stream_index.npy": (228,),
    "nominal_precoder_by_frequency.npy": (9, 57, 128, 4),
    "nominal_precoder_power_w.npy": (9, 57),
    "nominal_amplitude_by_frequency.npy": (9, 228, 57, 4),
    "nominal_user_desired_power_by_frequency_w.npy": (9, 228),
    "nominal_user_interference_power_by_frequency_w.npy": (9, 228),
    "nominal_user_sinr_by_frequency.npy": (9, 228),
    "nominal_user_rate_by_frequency.npy": (9, 228),
    "nominal_total_weighted_rate_per_user.npy": (228,),
    "protected_amp_perpendicular.npy": (228, 57, 4),
    "protected_amp_pol1.npy": (228, 57, 4),
    "protected_amp_pol2.npy": (228, 57, 4),
    "protected_steering_pol1.npy": (57, 128),
    "protected_steering_pol2.npy": (57, 128),
    "protected_mode_coefficients.npy": (57, 2, 4),
    "nominal_mode_leakage_w.npy": (57, 2),
    "kappa_time_sector.npy": (587, 57),
    "protected_time_s.npy": (587,),
    "aggregate_allowance_w.npy": (587,),
    "nominal_aggregate_interference_w.npy": (587,),
    "common_scale_reference.npy": (587,),
    "common_scale_user_rate.npy": (587, 228),
}
for name, shape in expected_shapes.items():
    require_structural(
        tuple(arrays[name].shape) == shape,
        f"Unexpected shape for {name}: {arrays[name].shape}",
    )

weights = np.asarray(
    arrays["frequency_weights.npy"],
    dtype=np.float64,
)
noise64 = np.asarray(
    arrays["noise_power_by_frequency_w.npy"],
    dtype=np.float64,
)
serving = np.asarray(
    arrays["serving_bs_index.npy"],
    dtype=np.int64,
)
stream = np.asarray(
    arrays["serving_stream_index.npy"],
    dtype=np.int64,
)
amplitudes = np.asarray(
    arrays["nominal_amplitude_by_frequency.npy"]
)
desired_expected = np.asarray(
    arrays["nominal_user_desired_power_by_frequency_w.npy"],
    dtype=np.float64,
)
interference_expected = np.asarray(
    arrays["nominal_user_interference_power_by_frequency_w.npy"],
    dtype=np.float64,
)
sinr_expected = np.asarray(
    arrays["nominal_user_sinr_by_frequency.npy"],
    dtype=np.float64,
)
rate_expected = np.asarray(
    arrays["nominal_user_rate_by_frequency.npy"],
    dtype=np.float64,
)

record(
    "frequency_weight_sum",
    bool(np.isclose(weights.sum(), 1.0, rtol=0.0, atol=1e-14)),
    sum=float(weights.sum()),
)
record(
    "serving_association",
    bool(
        np.array_equal(
            np.bincount(serving, minlength=57),
            np.full(57, 4, dtype=np.int64),
        )
    ),
)

# Exported complex64 amplitudes -> desired, total, and interference power.
magnitude32 = np.abs(amplitudes).astype(np.float32, copy=False)
power32 = (magnitude32 * magnitude32).astype(
    np.float32,
    copy=False,
)
total32 = power32.sum(axis=(2, 3), dtype=np.float32)
desired32_from_amp = power32[
    :,
    np.arange(228),
    serving,
    stream,
]
interference32_from_amp = (
    total32 - desired32_from_amp
).astype(np.float32)

desired64_from_amp = desired32_from_amp.astype(np.float64)
total64_from_amp = total32.astype(np.float64)
interference64_from_amp = interference32_from_amp.astype(np.float64)
total_expected = desired_expected + interference_expected

desired_abs = np.abs(desired64_from_amp - desired_expected)
desired_ok = bool(
    np.allclose(
        desired64_from_amp,
        desired_expected,
        rtol=8e-6,
        atol=1e-20,
    )
)
record(
    "desired_power_reconstruction",
    desired_ok,
    maximum_absolute_error=max_abs(desired_abs),
    maximum_relative_error=max_relative(
        desired64_from_amp,
        desired_expected,
        1e-30,
    ),
)

# Compare two valid float32 reductions over 228 nonnegative stream powers.
# The bound scales with total received power, not the near-zero interference
# residual produced by subtracting desired power.
total_abs = np.abs(total64_from_amp - total_expected)
reduction_terms = 57 * 4
reduction_gamma = gamma_n(reduction_terms)
total_allowed = (
    16.0
    * reduction_gamma
    * np.maximum(np.abs(total_expected), np.abs(total64_from_amp))
    + 2.0 * desired_abs
    + 64.0 * FLOAT32_TINY
)
total_ok = bool(np.all(total_abs <= total_allowed))
record(
    "total_received_power_reduction",
    total_ok,
    reduction_terms=reduction_terms,
    gamma_n=reduction_gamma,
    safety_factor=16.0,
    maximum_absolute_error=max_abs(total_abs),
    maximum_relative_error=max_relative(
        total64_from_amp,
        total_expected,
        1e-30,
    ),
    maximum_error_to_bound_ratio=float(
        np.max(
            total_abs
            / np.maximum(total_allowed, np.finfo(np.float64).tiny)
        )
    ),
)

interference_abs = np.abs(
    interference64_from_amp - interference_expected
)
interference_allowed = (
    total_abs
    + desired_abs
    + 8.0
    * FLOAT32_U
    * (np.abs(total_expected) + np.abs(desired_expected))
    + 64.0 * FLOAT32_TINY
)
interference_ok = bool(
    total_ok
    and desired_ok
    and np.all(interference_abs <= interference_allowed)
)
record(
    "interference_power_reconstruction",
    interference_ok,
    maximum_absolute_error=max_abs(interference_abs),
    maximum_relative_error_diagnostic_only=max_relative(
        interference64_from_amp,
        interference_expected,
        1e-30,
    ),
    maximum_error_to_bound_ratio=float(
        np.max(
            interference_abs
            / np.maximum(
                interference_allowed,
                np.finfo(np.float64).tiny,
            )
        )
    ),
    acceptance_basis=(
        "total-power forward-error bound plus desired-power error"
    ),
)

# Stored desired/interference -> SINR/rate in float32.
stored_sinr_float32 = bool(
    np.array_equal(
        sinr_expected,
        sinr_expected.astype(np.float32).astype(np.float64),
    )
)
stored_rate_float32 = bool(
    np.array_equal(
        rate_expected,
        rate_expected.astype(np.float32).astype(np.float64),
    )
)
record(
    "stored_float32_origin",
    stored_sinr_float32 and stored_rate_float32,
    sinr_is_exact_float32_cast=stored_sinr_float32,
    rate_is_exact_float32_cast=stored_rate_float32,
)

desired32 = desired_expected.astype(np.float32)
interference32 = interference_expected.astype(np.float32)
noise32 = noise64.astype(np.float32)
sinr32 = desired32 / (interference32 + noise32[:, None])
rate32 = np.log2(
    np.float32(1.0) + sinr32
).astype(np.float32)
sinr_reference32 = sinr_expected.astype(np.float32)
rate_reference32 = rate_expected.astype(np.float32)

sinr_ok = bool(
    np.allclose(
        sinr32,
        sinr_reference32,
        rtol=8e-6,
        atol=2e-7,
    )
)
rate_ok = bool(
    np.allclose(
        rate32,
        rate_reference32,
        rtol=8e-6,
        atol=5e-7,
    )
)
record(
    "sinr_reconstruction",
    sinr_ok,
    maximum_absolute_error=max_abs(
        sinr32.astype(np.float64) - sinr_expected
    ),
    maximum_relative_error=max_relative(
        sinr32.astype(np.float64),
        sinr_expected,
        1e-30,
    ),
    maximum_float32_ulp_distance=float32_ulp_distance(
        sinr32,
        sinr_reference32,
    ),
    rtol=8e-6,
    atol=2e-7,
)
record(
    "rate_reconstruction",
    rate_ok,
    maximum_absolute_error=max_abs(
        rate32.astype(np.float64) - rate_expected
    ),
    maximum_relative_error=max_relative(
        rate32.astype(np.float64),
        rate_expected,
        1e-30,
    ),
    maximum_float32_ulp_distance=float32_ulp_distance(
        rate32,
        rate_reference32,
    ),
    rtol=8e-6,
    atol=5e-7,
)

weighted_total = (weights[:, None] * rate_expected).sum(axis=0)
stored_total_rate = np.asarray(
    arrays["nominal_total_weighted_rate_per_user.npy"],
    dtype=np.float64,
)
weighted_rate_error = max_abs(
    weighted_total - stored_total_rate
)
record(
    "weighted_total_rate_reconstruction",
    weighted_rate_error <= 1e-10,
    maximum_absolute_error=weighted_rate_error,
    tolerance=1e-10,
)

# Complete raw channel + nominal precoder -> all exported amplitudes.
h = arrays["frequency_response.npy"]
w = arrays["nominal_precoder_by_frequency.npy"]
dot_gamma = gamma_n(128)
dot_safety_factor = 64.0
amplitude_error_max = 0.0
amplitude_bound_ratio_max = 0.0
for frequency in range(9):
    w_frequency = np.asarray(w[frequency])
    abs_w = np.abs(w_frequency).astype(np.float64)
    for start_user in range(0, 228, 12):
        stop_user = min(start_user + 12, 228)
        h_chunk = np.asarray(
            h[frequency, start_user:stop_user]
        )
        reference = np.asarray(
            amplitudes[frequency, start_user:stop_user]
        )
        reconstructed = np.einsum(
            "ubm,bmk->ubk",
            h_chunk,
            w_frequency,
            optimize=True,
        )
        sum_abs = np.einsum(
            "ubm,bmk->ubk",
            np.abs(h_chunk).astype(np.float64),
            abs_w,
            optimize=True,
        )
        error = np.abs(reconstructed - reference)
        allowed = (
            dot_safety_factor * dot_gamma * sum_abs
            + 64.0 * FLOAT32_TINY
        )
        amplitude_error_max = max(
            amplitude_error_max,
            max_abs(error),
        )
        amplitude_bound_ratio_max = max(
            amplitude_bound_ratio_max,
            float(
                np.max(
                    error
                    / np.maximum(
                        allowed,
                        np.finfo(np.float64).tiny,
                    )
                )
            ),
        )
record(
    "full_channel_precoder_amplitude_linkage",
    amplitude_bound_ratio_max <= 1.0,
    reduction_terms=128,
    gamma_n=dot_gamma,
    safety_factor=dot_safety_factor,
    maximum_absolute_error=amplitude_error_max,
    maximum_error_to_bound_ratio=amplitude_bound_ratio_max,
    coverage="all 9 frequencies, 228 users, 57 sectors, 4 streams",
)

# RZF power normalization.
precoder = np.asarray(w)
precoder_power = np.sum(
    np.abs(precoder) ** 2,
    axis=(2, 3),
    dtype=np.float32,
).astype(np.float64)
stored_precoder_power = np.asarray(
    arrays["nominal_precoder_power_w.npy"],
    dtype=np.float64,
)
record(
    "precoder_power_reconstruction",
    bool(
        np.allclose(
            precoder_power,
            stored_precoder_power,
            rtol=8e-6,
            atol=2e-7,
        )
    ),
    maximum_absolute_error=max_abs(
        precoder_power - stored_precoder_power
    ),
    maximum_relative_error=max_relative(
        precoder_power,
        stored_precoder_power,
        1e-30,
    ),
)

transmit_power = np.asarray(
    arrays["transmit_power_by_frequency_w.npy"],
    dtype=np.float64,
)
normalization_rel = max_relative(
    stored_precoder_power,
    np.broadcast_to(
        transmit_power[:, None],
        stored_precoder_power.shape,
    ),
    1e-30,
)
record(
    "rzf_power_normalization",
    normalization_rel <= 3e-6,
    maximum_relative_error=normalization_rel,
    tolerance=3e-6,
)

# ------------------------------------------------------------------
# Protected-mode source-linked decomposition.
# ------------------------------------------------------------------
protected = 4
a0 = np.asarray(
    arrays["protected_amp_perpendicular.npy"]
)
a1 = np.asarray(arrays["protected_amp_pol1.npy"])
a2 = np.asarray(arrays["protected_amp_pol2.npy"])
protected_reference = np.asarray(amplitudes[protected])
steering1 = np.asarray(
    arrays["protected_steering_pol1.npy"]
)
steering2 = np.asarray(
    arrays["protected_steering_pol2.npy"]
)
protected_precoder = np.asarray(w[protected])
coefficients = np.asarray(
    arrays["protected_mode_coefficients.npy"]
)

# These bounds cover the composed CUDA complex64 chain:
# steering normalization -> 128-term mode coefficient -> rank-one matrix ->
# 128-term channel contraction. The factor is deliberately tied to gamma_n
# and the magnitude sums of the actual operands, rather than to the possibly
# cancelled output amplitude.
PROJECTOR_DOT_SAFETY = 128.0
PROJECTOR_MUL_SAFETY = 32.0
PROJECTOR_SUB_SAFETY = 64.0

support_ok = True
orthogonality_max = 0.0
unit_magnitude_error_max = 0.0
projector_identity_error_max = 0.0
component_error_max = [0.0, 0.0, 0.0]
component_bound_ratio_max = [0.0, 0.0, 0.0]
direct_identity_error_max = 0.0
direct_identity_bound_ratio_max = 0.0

# Also retain the steering-coefficient reconstruction as a separate check.
coefficient_error_max = 0.0
coefficient_ratio_max = 0.0

h_protected = h[protected]
for sector in range(57):
    h_sector = np.asarray(
        h_protected[:, sector, :],
        dtype=np.complex128,
    )
    w_sector = np.asarray(
        protected_precoder[sector],
        dtype=np.complex128,
    )
    s1 = np.asarray(
        steering1[sector],
        dtype=np.complex128,
    )
    s2 = np.asarray(
        steering2[sector],
        dtype=np.complex128,
    )

    mask1 = np.abs(s1) > 0.0
    mask2 = np.abs(s2) > 0.0
    support_ok = bool(
        support_ok
        and int(mask1.sum()) == 64
        and int(mask2.sum()) == 64
        and not np.any(mask1 & mask2)
    )
    if np.any(mask1):
        unit_magnitude_error_max = max(
            unit_magnitude_error_max,
            max_abs(np.abs(s1[mask1]) - 1.0),
        )
    if np.any(mask2):
        unit_magnitude_error_max = max(
            unit_magnitude_error_max,
            max_abs(np.abs(s2[mask2]) - 1.0),
        )

    norm1 = float(np.linalg.norm(s1))
    norm2 = float(np.linalg.norm(s2))
    require_structural(
        norm1 > 0.0 and norm2 > 0.0,
        f"Zero steering norm at sector {sector}",
    )
    u1 = s1 / norm1
    u2 = s2 / norm2
    orthogonality_max = max(
        orthogonality_max,
        float(abs(np.vdot(u1, u2))),
    )

    # Complex128 mathematical reference built from the exact stored complex64
    # inputs. The exporter evaluates the same formulas in complex64.
    coeff1_ref = u1.conj() @ w_sector
    coeff2_ref = u2.conj() @ w_sector
    p1_ref = u1[:, None] * coeff1_ref[None, :]
    p2_ref = u2[:, None] * coeff2_ref[None, :]
    perp_ref = w_sector - p1_ref - p2_ref

    projector_identity_error_max = max(
        projector_identity_error_max,
        max_abs(perp_ref + p1_ref + p2_ref - w_sector),
    )

    # Propagate coefficient and multiplication roundoff into each projector.
    coeff1_sum_abs = (
        np.abs(u1).astype(np.float64)
        @ np.abs(w_sector).astype(np.float64)
    )
    coeff2_sum_abs = (
        np.abs(u2).astype(np.float64)
        @ np.abs(w_sector).astype(np.float64)
    )
    coeff1_bound = (
        PROJECTOR_DOT_SAFETY
        * dot_gamma
        * coeff1_sum_abs
        + 64.0 * FLOAT32_TINY
    )
    coeff2_bound = (
        PROJECTOR_DOT_SAFETY
        * dot_gamma
        * coeff2_sum_abs
        + 64.0 * FLOAT32_TINY
    )
    p1_bound = (
        np.abs(u1)[:, None] * coeff1_bound[None, :]
        + PROJECTOR_MUL_SAFETY
        * FLOAT32_U
        * np.abs(p1_ref)
        + 64.0 * FLOAT32_TINY
    )
    p2_bound = (
        np.abs(u2)[:, None] * coeff2_bound[None, :]
        + PROJECTOR_MUL_SAFETY
        * FLOAT32_U
        * np.abs(p2_ref)
        + 64.0 * FLOAT32_TINY
    )
    perp_bound = (
        p1_bound
        + p2_bound
        + PROJECTOR_SUB_SAFETY
        * FLOAT32_U
        * (
            np.abs(w_sector)
            + np.abs(p1_ref)
            + np.abs(p2_ref)
        )
        + 64.0 * FLOAT32_TINY
    )

    matrix_refs = (perp_ref, p1_ref, p2_ref)
    matrix_bounds = (perp_bound, p1_bound, p2_bound)
    exported_components = (
        np.asarray(a0[:, sector, :], dtype=np.complex128),
        np.asarray(a1[:, sector, :], dtype=np.complex128),
        np.asarray(a2[:, sector, :], dtype=np.complex128),
    )

    component_refs = []
    component_bounds = []
    abs_h = np.abs(h_sector).astype(np.float64)
    for component_index, (
        matrix_ref,
        matrix_bound,
        exported,
    ) in enumerate(
        zip(matrix_refs, matrix_bounds, exported_components)
    ):
        reference = h_sector @ matrix_ref
        # Input-matrix roundoff propagated through H, plus the complex dot
        # product forward-error bound.
        bound = (
            abs_h @ matrix_bound
            + PROJECTOR_DOT_SAFETY
            * dot_gamma
            * (abs_h @ np.abs(matrix_ref).astype(np.float64))
            + 64.0 * FLOAT32_TINY
        )
        error = np.abs(exported - reference)
        ratio = float(
            np.max(
                error
                / np.maximum(
                    bound,
                    np.finfo(np.float64).tiny,
                )
            )
        )
        component_error_max[component_index] = max(
            component_error_max[component_index],
            max_abs(error),
        )
        component_bound_ratio_max[component_index] = max(
            component_bound_ratio_max[component_index],
            ratio,
        )
        component_refs.append(reference)
        component_bounds.append(bound)

    # Independently link the stored nominal protected amplitude to H @ W.
    nominal_reference = h_sector @ w_sector
    nominal_bound = (
        PROJECTOR_DOT_SAFETY
        * dot_gamma
        * (
            abs_h
            @ np.abs(w_sector).astype(np.float64)
        )
        + 64.0 * FLOAT32_TINY
    )
    nominal_export = np.asarray(
        protected_reference[:, sector, :],
        dtype=np.complex128,
    )
    nominal_error = np.abs(
        nominal_export - nominal_reference
    )

    # The direct identity residual is accepted only when it is explained by
    # the independently computed component-linkage and nominal-linkage bounds.
    direct_residual = np.abs(
        exported_components[0]
        + exported_components[1]
        + exported_components[2]
        - nominal_export
    )
    propagated_identity_bound = (
        component_bounds[0]
        + component_bounds[1]
        + component_bounds[2]
        + nominal_bound
        + PROJECTOR_SUB_SAFETY
        * FLOAT32_U
        * (
            np.abs(exported_components[0])
            + np.abs(exported_components[1])
            + np.abs(exported_components[2])
            + np.abs(nominal_export)
        )
        + 64.0 * FLOAT32_TINY
    )
    direct_identity_error_max = max(
        direct_identity_error_max,
        max_abs(direct_residual),
    )
    direct_identity_bound_ratio_max = max(
        direct_identity_bound_ratio_max,
        float(
            np.max(
                direct_residual
                / np.maximum(
                    propagated_identity_bound,
                    np.finfo(np.float64).tiny,
                )
            )
        ),
    )

    # Existing mode-coefficient linkage, now evaluated alongside the source
    # projectors.
    for mode_index, steering in enumerate((s1, s2)):
        reconstructed = (
            steering.conj() @ w_sector
        )
        reference = np.asarray(
            coefficients[sector, mode_index],
            dtype=np.complex128,
        )
        sum_abs = (
            np.abs(steering).astype(np.float64)
            @ np.abs(w_sector).astype(np.float64)
        )
        error = np.abs(reconstructed - reference)
        allowed = (
            PROJECTOR_DOT_SAFETY
            * dot_gamma
            * sum_abs
            + 64.0 * FLOAT32_TINY
        )
        coefficient_error_max = max(
            coefficient_error_max,
            max_abs(error),
        )
        coefficient_ratio_max = max(
            coefficient_ratio_max,
            float(
                np.max(
                    error
                    / np.maximum(
                        allowed,
                        np.finfo(np.float64).tiny,
                    )
                )
            ),
        )

component_linkage_ok = bool(
    max(component_bound_ratio_max) <= 1.0
)
protected_identity_ok = bool(
    support_ok
    and orthogonality_max <= 1e-14
    and unit_magnitude_error_max <= 2e-6
    and projector_identity_error_max <= 1e-14
    and component_linkage_ok
    and direct_identity_bound_ratio_max <= 1.0
)

record(
    "protected_mode_support_and_orthogonality",
    bool(
        support_ok
        and orthogonality_max <= 1e-14
        and unit_magnitude_error_max <= 2e-6
    ),
    support_counts_expected=64,
    maximum_cross_mode_inner_product=orthogonality_max,
    maximum_nonzero_magnitude_error=unit_magnitude_error_max,
)
record(
    "protected_projector_matrix_identity",
    projector_identity_error_max <= 1e-14,
    maximum_absolute_error=projector_identity_error_max,
)
record(
    "protected_component_source_linkage",
    component_linkage_ok,
    component_names=[
        "perpendicular",
        "polarization_1",
        "polarization_2",
    ],
    maximum_absolute_errors=component_error_max,
    maximum_error_to_bound_ratios=component_bound_ratio_max,
    dot_safety_factor=PROJECTOR_DOT_SAFETY,
    multiply_safety_factor=PROJECTOR_MUL_SAFETY,
    subtraction_safety_factor=PROJECTOR_SUB_SAFETY,
    coverage="all 228 users, 57 sectors, 4 streams",
)
record(
    "protected_amplitude_decomposition",
    protected_identity_ok,
    maximum_direct_sum_absolute_error=direct_identity_error_max,
    maximum_direct_sum_error_to_propagated_bound_ratio=(
        direct_identity_bound_ratio_max
    ),
    acceptance_basis=(
        "independent H@W_perp, H@P1, H@P2 and H@W source linkages "
        "plus propagated float32 forward-error bounds"
    ),
)
record(
    "mode_coefficient_reconstruction",
    coefficient_ratio_max <= 1.0,
    maximum_absolute_error=coefficient_error_max,
    maximum_error_to_bound_ratio=coefficient_ratio_max,
)

leakage = np.sum(
    np.abs(coefficients) ** 2,
    axis=2,
    dtype=np.float32,
).astype(np.float64)
stored_leakage = np.asarray(
    arrays["nominal_mode_leakage_w.npy"],
    dtype=np.float64,
)
record(
    "mode_leakage_reconstruction",
    bool(
        np.allclose(
            leakage,
            stored_leakage,
            rtol=1e-5,
            atol=1e-12,
        )
    ),
    maximum_absolute_error=max_abs(leakage - stored_leakage),
    maximum_relative_error=max_relative(
        leakage,
        stored_leakage,
        1e-30,
    ),
)

# Incumbent aggregation and common-scale reference.
kappa = np.asarray(
    arrays["kappa_time_sector.npy"],
    dtype=np.float64,
)
nominal_aggregate = kappa @ stored_leakage.sum(axis=1)
stored_aggregate = np.asarray(
    arrays["nominal_aggregate_interference_w.npy"],
    dtype=np.float64,
)
record(
    "aggregate_incumbent_reconstruction",
    bool(
        np.allclose(
            nominal_aggregate,
            stored_aggregate,
            rtol=1e-12,
            atol=1e-24,
        )
    ),
    maximum_absolute_error_w=max_abs(
        nominal_aggregate - stored_aggregate
    ),
    maximum_relative_error=max_relative(
        nominal_aggregate,
        stored_aggregate,
        1e-300,
    ),
)

scale = np.asarray(
    arrays["common_scale_reference.npy"],
    dtype=np.float64,
)
allowance = np.asarray(
    arrays["aggregate_allowance_w.npy"],
    dtype=np.float64,
)
safe_aggregate = nominal_aggregate * scale**2
record(
    "common_scale_aggregate_safety",
    bool(
        np.all(
            safe_aggregate
            <= allowance * (1.0 + 3e-6) + 1e-30
        )
    ),
    maximum_safe_minus_allowance_w=float(
        np.max(safe_aggregate - allowance)
    ),
)

other_rate = np.asarray(
    arrays["other_frequency_weighted_rate_per_user.npy"],
    dtype=np.float64,
)
protected_weight = float(weights[protected])
protected_noise = float(noise64[protected])
stored_common_rate = np.asarray(
    arrays["common_scale_user_rate.npy"],
    dtype=np.float64,
)
common_rate_error = 0.0
for time_index, value in enumerate(scale):
    safe_amplitude = a0 + value * a1 + value * a2
    safe_power = np.abs(safe_amplitude) ** 2
    safe_total = safe_power.sum(axis=(1, 2))
    safe_desired = safe_power[
        np.arange(228),
        serving,
        stream,
    ]
    safe_sinr = safe_desired / (
        safe_total - safe_desired + protected_noise
    )
    safe_rate = (
        other_rate
        + protected_weight * np.log2(1.0 + safe_sinr)
    )
    common_rate_error = max(
        common_rate_error,
        max_abs(
            safe_rate - stored_common_rate[time_index]
        ),
    )
record(
    "common_scale_user_rate_reconstruction",
    common_rate_error <= 2e-8,
    maximum_absolute_error_bps_hz=common_rate_error,
    tolerance=2e-8,
)

users = pd.read_csv(OUTPUT / "USER_TOPOLOGY.csv")
sectors = pd.read_csv(OUTPUT / "SECTOR_TOPOLOGY.csv")
record(
    "topology_tables",
    bool(
        len(users) == 228
        and len(sectors) == 57
        and users["user_id"].nunique() == 228
        and sectors["sector_id"].nunique() == 57
    ),
    user_rows=len(users),
    sector_rows=len(sectors),
)

diagnostics = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "status": (
        "PASS_CONTROLLER_READY_FULL_TOPOLOGY_EXPORT_VALIDATION_V4"
        if not failures
        else "FAIL_CONTROLLER_READY_FULL_TOPOLOGY_EXPORT_VALIDATION_V4"
    ),
    "source_h100_job_id": "18696267",
    "source_h100_job_state": (
        "FAILED_AFTER_SUCCESSFUL_EXPORT_DUE_TO_SUPERSEDED_VALIDATOR"
    ),
    "prior_cpu_validator_job_id": "18699475",
    "prior_cpu_validator_disposition": (
        "SUPERSEDED_NEAR_ZERO_INTERFERENCE_RELATIVE_ERROR_TEST"
    ),
    "prior_cpu_validator_v3_job_id": "18702280",
    "prior_cpu_validator_v3_disposition": (
        "SUPERSEDED_INCOMPLETE_PROTECTED_SUM_BOUND"
    ),
    "floating_point_contract": {
        "float32_unit_roundoff": FLOAT32_U,
        "float32_epsilon": FLOAT32_EPS,
        "interference_acceptance": (
            "total-power forward-error bound plus desired-power error; "
            "relative residual error is diagnostic only near zero"
        ),
        "dot_product_acceptance": (
            "magnitude-sum-scaled gamma_n forward-error bound"
        ),
        "protected_decomposition_acceptance": (
            "source-linked reconstruction of P1, P2, W_perp and all three "
            "amplitude components, followed by a propagated identity bound"
        ),
        "sinr_rate_acceptance": (
            "hybrid float32 rtol/atol with recorded ULP distance"
        ),
    },
    "checks": checks,
    "failures": failures,
    "claim_boundary": (
        "CONTROLLER_READY_FULL_TOPOLOGY_EXPORT_ONE_SEED_NOT_PAPER_RESULT"
    ),
    "next_gate": (
        "LOCAL_INGESTION_THEN_DYNAMIC_CONTROLLER_IMPLEMENTATION"
    ),
}

for path in [
    OUTPUT / "FULL_TOPOLOGY_EXPORT_VALIDATION_V4.json",
    RECOVERY / "FULL_TOPOLOGY_EXPORT_VALIDATION_V4.json",
]:
    path.write_text(
        json.dumps(diagnostics, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

print(json.dumps(diagnostics, indent=2, sort_keys=True))
if failures:
    raise ValueError(
        "Corrected validation failed checks: "
        + ", ".join(failures)
    )

print(
    "CONTROLLER-READY FULL-TOPOLOGY EXPORT "
    "VALIDATION V4: PASS"
)

