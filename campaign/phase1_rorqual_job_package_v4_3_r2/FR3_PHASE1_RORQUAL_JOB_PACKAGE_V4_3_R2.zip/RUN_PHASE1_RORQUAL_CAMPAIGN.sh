#!/usr/bin/env bash
set -Eeuo pipefail
echo "ERROR: candidate-v4.3 phase-1 execution is locked"
echo "No execution authorization token is included in this package"
echo "Required next gate: separate Rorqual full-campaign authorization"
echo "CAMPAIGN_EXECUTION_AUTHORIZED=NO"
exit 64
