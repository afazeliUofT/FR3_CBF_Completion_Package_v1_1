#!/usr/bin/env python3
"""Create a compact, portable seed-result return on success or failure."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tempfile
import zipfile


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed-root", required=True)
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--package-id", required=True)
    parser.add_argument("--worker-exit-code", required=True, type=int)
    parser.add_argument("--validator-exit-code", required=True, type=int)
    args = parser.parse_args()
    seed_root = Path(args.seed_root).expanduser().resolve()
    result = seed_root / "result"
    output = seed_root / f"FR3_PHASE1_SEED_{args.seed}_RETURN.zip"

    with tempfile.TemporaryDirectory(prefix="fr3-seed-return-") as temp_name:
        temp = Path(temp_name)
        payload = temp / f"FR3_PHASE1_SEED_{args.seed}_RETURN"
        payload.mkdir()
        for name in ("worker_stdout.log", "worker_stderr.log"):
            source = seed_root / name
            if source.is_file():
                (payload / name).write_bytes(source.read_bytes())
        channel_record = seed_root / "channel" / "CHANNEL_RECORD.json"
        if channel_record.is_file():
            (payload / "CHANNEL_RECORD.json").write_bytes(channel_record.read_bytes())
        if result.is_dir():
            target = payload / "result"
            target.mkdir()
            for source in sorted(result.iterdir()):
                if source.is_file():
                    (target / source.name).write_bytes(source.read_bytes())
        metadata = {
            "schema_version": 1,
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "campaign_seed": int(args.seed),
            "package_id": args.package_id,
            "worker_exit_code": int(args.worker_exit_code),
            "validator_exit_code": int(args.validator_exit_code),
            "scientific_failure_preserved": int(args.worker_exit_code) == 42,
            "full_channel_arrays_included": False,
        }
        write_json(payload / "SEED_RETURN_METADATA.json", metadata)
        manifest = {}
        for source in sorted(payload.rglob("*")):
            if source.is_file() and source.name != "SEED_RETURN_MANIFEST.sha256":
                relative = source.relative_to(payload).as_posix()
                manifest[relative] = sha256_file(source)
        (payload / "SEED_RETURN_MANIFEST.sha256").write_text(
            "".join(f"{digest}  {name}\n" for name, digest in sorted(manifest.items())),
            encoding="utf-8",
        )
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
            for source in sorted(payload.rglob("*")):
                if source.is_file():
                    archive.write(source, source.relative_to(temp).as_posix())
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("seed return ZIP CRC failure")
    digest = sha256_file(output)
    Path(str(output) + ".sha256").write_text(
        f"{digest}  {output.name}\n", encoding="utf-8"
    )
    print(f"SEED_RETURN_ZIP={output}")
    print(f"SEED_RETURN_ZIP_SHA256={digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
