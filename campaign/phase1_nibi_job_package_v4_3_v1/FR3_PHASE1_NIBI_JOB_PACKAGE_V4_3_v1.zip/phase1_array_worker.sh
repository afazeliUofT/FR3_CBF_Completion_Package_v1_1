#!/usr/bin/env bash
set -Eeuo pipefail

: "${PHASE1_PACKAGE_ROOT:?PHASE1_PACKAGE_ROOT is required}"
: "${PHASE1_RUN_ROOT:?PHASE1_RUN_ROOT is required}"
: "${PHASE1_VENV:?PHASE1_VENV is required}"
: "${PHASE1_AUTHORIZATION_FILE:?PHASE1_AUTHORIZATION_FILE is required}"
: "${SLURM_ARRAY_TASK_ID:?SLURM_ARRAY_TASK_ID is required}"

ROOT="$PHASE1_PACKAGE_ROOT"
RUN="$PHASE1_RUN_ROOT"
VENV="$PHASE1_VENV"

module --force purge
module load StdEnv/2023
module load python/3.12.4
source "$VENV/bin/activate"

export PYTHONHASHSEED=0
export PYTHONDONTWRITEBYTECODE=1
export CUDA_CACHE_PATH="$RUN/cache/cuda"
export XDG_CACHE_HOME="$RUN/cache/xdg"
export TMPDIR="$RUN/cache/tmp"
export TORCH_HOME="$RUN/cache/torch"
export TORCH_EXTENSIONS_DIR="$RUN/cache/torch_extensions"
export MPLCONFIGDIR="$RUN/cache/matplotlib"
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-16}"
export MKL_NUM_THREADS="${SLURM_CPUS_PER_TASK:-16}"
export OPENBLAS_NUM_THREADS="${SLURM_CPUS_PER_TASK:-16}"

mkdir -p "$RUN/results" "$RUN/cache/cuda" "$RUN/cache/xdg" "$RUN/cache/tmp"
(
  cd "$ROOT"
  sha256sum -c PACKAGE_MANIFEST.sha256 >/dev/null
)
echo "REMOTE_PACKAGE_MANIFEST_VERIFICATION=PASS"

nvidia-smi
python - <<'PY'
import torch
assert torch.cuda.is_available()
name = torch.cuda.get_device_name(0)
memory = torch.cuda.get_device_properties(0).total_memory / 1024**3
assert "H100" in name, name
assert memory >= 75.0, memory
print("PHASE1_H100_PROBE=PASS")
print("GPU_NAME=" + name)
print(f"GPU_MEMORY_GIB={memory:.6f}")
PY

SEED="$(python - "$ROOT/JOB_PACKAGE_CONTRACT.json" "$SLURM_ARRAY_TASK_ID" <<'PY'
import json, sys
contract=json.load(open(sys.argv[1], encoding='utf-8'))
index=int(sys.argv[2])
print(contract['campaign_seed_list'][index])
PY
)"
SEED_ROOT="$RUN/results/seed_${SEED}"
mkdir -p "$SEED_ROOT"

WORKER_ARGS=(
  "$VENV/bin/python" "$ROOT/phase1_seed_worker.py"
  --array-index "$SLURM_ARRAY_TASK_ID"
  --output-root "$RUN/results"
)
if [[ "${PHASE1_REUSE_CHANNEL:-0}" == "1" ]]; then
  WORKER_ARGS+=(--reuse-channel)
fi

if "${WORKER_ARGS[@]}" >"$SEED_ROOT/worker_stdout.log" 2>"$SEED_ROOT/worker_stderr.log"; then
  WORKER_RC=0
else
  WORKER_RC=$?
fi

VALIDATOR_RC=99
if [[ -d "$SEED_ROOT/result" ]]; then
  if "$VENV/bin/python" "$ROOT/validate_seed_result.py" \
      --result-dir "$SEED_ROOT/result" \
      --package-contract "$ROOT/JOB_PACKAGE_CONTRACT.json"; then
    VALIDATOR_RC=0
  else
    VALIDATOR_RC=$?
  fi
fi

PACKAGE_ID="$(python - "$ROOT/JOB_PACKAGE_CONTRACT.json" <<'PY'
import json,sys
print(json.load(open(sys.argv[1], encoding='utf-8'))['package_id'])
PY
)"
"$VENV/bin/python" "$ROOT/package_seed_result.py" \
  --seed-root "$SEED_ROOT" \
  --seed "$SEED" \
  --package-id "$PACKAGE_ID" \
  --worker-exit-code "$WORKER_RC" \
  --validator-exit-code "$VALIDATOR_RC"

printf '%s\n' \
  "CAMPAIGN_SEED=$SEED" \
  "PHASE1_SEED_WORKER_EXIT_CODE=$WORKER_RC" \
  "PHASE1_SEED_VALIDATOR_EXIT_CODE=$VALIDATOR_RC" \
  "SEED_RESULT_RETURN_PACKAGING=PASS"

if [[ "$VALIDATOR_RC" -ne 0 ]]; then
  exit "$VALIDATOR_RC"
fi
exit "$WORKER_RC"
