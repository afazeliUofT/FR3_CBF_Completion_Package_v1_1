#!/usr/bin/env bash
set -Eeuo pipefail

: "${PHASE1_PACKAGE_ROOT:?PHASE1_PACKAGE_ROOT is required}"
: "${PHASE1_RUN_ROOT:?PHASE1_RUN_ROOT is required}"
: "${PHASE1_VENV:?PHASE1_VENV is required}"

ROOT="$PHASE1_PACKAGE_ROOT"
RUN="$PHASE1_RUN_ROOT"
VENV="$PHASE1_VENV"

module --force purge
module load StdEnv/2023
module load python/3.12.4
source "$VENV/bin/activate"
export PYTHONHASHSEED=0
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-16}"
export MKL_NUM_THREADS="${SLURM_CPUS_PER_TASK:-16}"
export OPENBLAS_NUM_THREADS="${SLURM_CPUS_PER_TASK:-16}"

MERGED="$RUN/merged"
if "$VENV/bin/python" "$ROOT/merge_phase1_results.py" \
    --seed-root "$RUN/results" \
    --package-root "$ROOT" \
    --output-root "$MERGED"; then
  MERGE_RC=0
else
  MERGE_RC=$?
fi
VALIDATE_RC=99
if [[ -f "$MERGED/PHASE1_MERGED_AUDIT.json" ]]; then
  if "$VENV/bin/python" "$ROOT/validate_merged_results.py" \
      --merged-dir "$MERGED"; then
    VALIDATE_RC=0
  else
    VALIDATE_RC=$?
  fi
fi
printf '%s\n' \
  "PHASE1_MERGE_EXIT_CODE=$MERGE_RC" \
  "PHASE1_MERGED_VALIDATOR_EXIT_CODE=$VALIDATE_RC" \
  "AFTER_ANY_FAILURE_PRESERVING_MERGE=YES"
if [[ "$VALIDATE_RC" -ne 0 && "$MERGE_RC" -eq 0 ]]; then
  exit "$VALIDATE_RC"
fi
exit "$MERGE_RC"
