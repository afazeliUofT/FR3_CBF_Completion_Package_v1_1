#!/usr/bin/env python3
"""Failure-preserving merge and preregistered analysis for 30 seed clusters."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

import numpy as np
import pandas as pd

CANDIDATE = "candidate_v4_3_floor_feasibility_repair"
STATIC = "static_robust_constrained_pf_with_sector_selective_fallback"
PREDICTIVE = "robust_predictive_constrained_pf_with_sector_selective_fallback"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def bootstrap_seed_clusters(values: np.ndarray, repetitions: int, seed: int) -> dict:
    x = np.asarray(values, dtype=np.float64)
    if x.shape != (30,) or not np.isfinite(x).all():
        raise ValueError("bootstrap input must be 30 finite seed-cluster effects")
    rng = np.random.default_rng(int(seed))
    indices = rng.integers(0, 30, size=(int(repetitions), 30))
    means = x[indices].mean(axis=1)
    return {
        "point_estimate": float(x.mean()),
        "seed_cluster_standard_deviation": float(x.std(ddof=1)),
        "median_bootstrap_mean": float(np.median(means)),
        "lower_95": float(np.quantile(means, 0.025)),
        "upper_95": float(np.quantile(means, 0.975)),
        "bootstrap_resamples": int(repetitions),
        "bootstrap_seed": int(seed),
    }


def package_output(output: Path) -> tuple[Path, str]:
    manifest = {}
    for path in sorted(output.iterdir()):
        if path.is_file() and not path.name.startswith("FR3_PHASE1_MERGED_REVIEW_RETURN"):
            manifest[path.name] = {
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
    write_json(output / "MERGED_FILE_MANIFEST.json", manifest)
    review = output / "FR3_PHASE1_MERGED_REVIEW_RETURN.zip"
    with zipfile.ZipFile(review, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(output.iterdir()):
            if path.is_file() and path != review and path.name != review.name + ".sha256":
                archive.write(path, path.name)
    with zipfile.ZipFile(review) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("merged review ZIP CRC failure")
    digest = sha256_file(review)
    Path(str(review) + ".sha256").write_text(
        f"{digest}  {review.name}\n", encoding="utf-8"
    )
    return review, digest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed-root", required=True)
    parser.add_argument("--package-root", required=True)
    parser.add_argument("--output-root", required=True)
    args = parser.parse_args()
    seed_root = Path(args.seed_root).expanduser().resolve()
    package_root = Path(args.package_root).expanduser().resolve()
    output = Path(args.output_root).expanduser().resolve()
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)

    contract = json.loads(
        (package_root / "JOB_PACKAGE_CONTRACT.json").read_text(encoding="utf-8")
    )
    campaign = json.loads(
        (package_root / "PHASE1_CAMPAIGN_CONTRACT_V4_3.json").read_text(encoding="utf-8")
    )
    seeds = [int(v) for v in contract["campaign_seed_list"]]
    validator = package_root / "validate_seed_result.py"
    all_cells: list[pd.DataFrame] = []
    all_paired: list[pd.DataFrame] = []
    seed_audits: list[dict] = []
    seed_hash_rows: list[dict] = []
    invalid: list[dict] = []

    for seed in seeds:
        result_dir = seed_root / f"seed_{seed}" / "result"
        try:
            completed = subprocess.run(
                [
                    "python3", str(validator),
                    "--result-dir", str(result_dir),
                    "--package-contract", str(package_root / "JOB_PACKAGE_CONTRACT.json"),
                ],
                capture_output=True,
                text=True,
                check=False,
            )
            if completed.returncode != 0:
                raise RuntimeError(completed.stdout + "\n" + completed.stderr)
            audit_path = result_dir / "SEED_RESULT.json"
            manifest_path = result_dir / "RESULT_FILE_MANIFEST.json"
            audit = json.loads(audit_path.read_text(encoding="utf-8"))
            cells = pd.read_csv(result_dir / "CELL_SUMMARY.csv")
            paired = pd.read_csv(result_dir / "PRIMARY_PAIRED_EFFECTS.csv")
            cells["campaign_seed"] = seed
            paired["campaign_seed"] = seed
            all_cells.append(cells)
            all_paired.append(paired)
            seed_audits.append(audit)
            return_zip = result_dir.parent / f"FR3_PHASE1_SEED_{seed}_RETURN.zip"
            channel_record_path = result_dir.parent / "channel" / "CHANNEL_RECORD.json"
            if not channel_record_path.is_file():
                raise FileNotFoundError(channel_record_path)
            channel_record_file = json.loads(
                channel_record_path.read_text(encoding="utf-8")
            )
            if channel_record_file != audit["channel_record"]:
                raise ValueError("embedded and on-disk channel records differ")
            seed_hash_rows.append(
                {
                    "campaign_seed": seed,
                    "seed_result_sha256": sha256_file(audit_path),
                    "result_manifest_sha256": sha256_file(manifest_path),
                    "channel_record_file_sha256": sha256_file(channel_record_path),
                    "channel_record_canonical_json_sha256": hashlib.sha256(
                        json.dumps(
                            audit["channel_record"], sort_keys=True, separators=(",", ":")
                        ).encode("utf-8")
                    ).hexdigest(),
                    "frequency_response_array_sha256": audit["channel_record"][
                        "frequency_response_sha256_array_bytes"
                    ],
                    "authorization_token_sha256": audit["authorization_token_sha256"],
                    "return_zip_present": return_zip.is_file(),
                    "return_zip_sha256": (
                        sha256_file(return_zip) if return_zip.is_file() else "NOT_PRESENT"
                    ),
                    "candidate_hard_gates_pass": bool(audit["candidate_hard_gates_pass"]),
                    "scientific_exit_code": int(audit["scientific_exit_code"]),
                }
            )
        except Exception as exc:  # failure is packaged, not hidden
            invalid.append({"campaign_seed": seed, "error": str(exc)})

    if invalid:
        incomplete = {
            "schema_version": 1,
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "status": "INCOMPLETE_OR_INVALID_PHASE1_V4_3_SEED_RESULTS",
            "expected_seed_count": 30,
            "valid_seed_count": len(seed_audits),
            "invalid_or_missing": invalid,
            "campaign_execution_authorized": False,
            "paper_result": False,
            "next_gate": "DIAGNOSE_AND_RERUN_ONLY_MISSING_OR_INVALID_SEEDS_AFTER_INDEPENDENT_REVIEW",
        }
        write_json(output / "PHASE1_MERGE_INCOMPLETE.json", incomplete)
        if seed_hash_rows:
            pd.DataFrame(seed_hash_rows).to_csv(
                output / "PHASE1_SEED_RESULT_HASH_INDEX.csv", index=False
            )
        review, digest = package_output(output)
        print("PHASE1_V4_3_MERGE_STATUS=INCOMPLETE_RETURN_READY")
        print(f"MERGED_REVIEW_ZIP={review}")
        print(f"MERGED_REVIEW_ZIP_SHA256={digest}")
        return 42

    cells = pd.concat(all_cells, ignore_index=True)
    paired = pd.concat(all_paired, ignore_index=True)
    if len(cells) != 1350 or len(paired) != 150:
        raise RuntimeError("complete merge dimensions are not 1350 cells / 150 pairs")
    cells.to_csv(output / "PHASE1_ALL_CELL_SUMMARY.csv", index=False)
    paired.to_csv(output / "PHASE1_PRIMARY_PAIRED_EFFECTS.csv", index=False)
    pd.DataFrame(seed_hash_rows).to_csv(
        output / "PHASE1_SEED_RESULT_HASH_INDEX.csv", index=False
    )

    effect_columns = [
        "candidate_minus_static_final_pf",
        "candidate_minus_static_duration_mean_pf",
        "candidate_minus_predictive_final_pf",
        "candidate_minus_predictive_duration_mean_pf",
    ]
    seed_effects = paired.groupby("campaign_seed")[effect_columns].mean().reindex(seeds)
    if seed_effects.isna().any().any():
        raise RuntimeError("seed-cluster effect is missing")
    seed_effects.reset_index().to_csv(
        output / "PHASE1_SEED_CLUSTER_EFFECTS.csv", index=False
    )

    repetitions = int(campaign["statistics"]["bootstrap_resamples"])
    bootstrap_seed = int(campaign["statistics"]["bootstrap_seed"])
    bootstrap = {
        name: bootstrap_seed_clusters(
            seed_effects[name].to_numpy(float), repetitions, bootstrap_seed + offset
        )
        for offset, name in enumerate(effect_columns)
    }
    write_json(output / "PHASE1_BOOTSTRAP_SUMMARY.json", bootstrap)

    pass_effects = paired.groupby("pass_slot")[effect_columns].agg(
        ["mean", "median", "std", "min", "max"]
    )
    pass_effects.columns = ["__".join(column) for column in pass_effects.columns]
    pass_effects.reset_index().to_csv(
        output / "PHASE1_PASS_SPECIFIC_EFFECTS.csv", index=False
    )

    endpoint_columns = [
        "final_moving_pf_utility",
        "duration_weighted_mean_moving_pf_utility",
        "protected_active_eligible_p05_bps_hz",
        "protected_active_eligible_geometric_mean_bps_hz",
        "total_active_eligible_p05_bps_hz",
        "total_active_eligible_geometric_mean_bps_hz",
        "long_violation_seconds",
        "short_violation_seconds",
        "eligible_floor_violation_user_seconds",
        "eligible_floor_violation_user_intervals",
        "intervals_with_any_sector_mute",
        "maximum_muted_sector_count",
    ]
    endpoint_summary = cells.groupby("method_id", sort=False)[endpoint_columns].agg(
        ["mean", "median", "std", "min", "max"]
    )
    endpoint_summary.columns = [
        "__".join(column) for column in endpoint_summary.columns
    ]
    endpoint_summary.reset_index().to_csv(
        output / "PHASE1_METHOD_ENDPOINT_SUMMARY.csv", index=False
    )

    leave_one = []
    for omitted in range(5):
        reduced = (
            paired.loc[paired["pass_slot"] != omitted]
            .groupby("campaign_seed")["candidate_minus_static_final_pf"]
            .mean()
            .reindex(seeds)
            .to_numpy(float)
        )
        record = bootstrap_seed_clusters(reduced, repetitions, bootstrap_seed + 100 + omitted)
        record["omitted_pass_slot"] = omitted
        leave_one.append(record)
    pd.DataFrame(leave_one).to_csv(
        output / "PHASE1_LEAVE_ONE_PASS_OUT.csv", index=False
    )

    candidate = cells.loc[cells["method_id"] == CANDIDATE].copy()
    hard_gates = {
        "zero_long_eess_violation_seconds": int(candidate["long_violation_seconds"].sum()) == 0,
        "zero_short_eess_violation_seconds": int(candidate["short_violation_seconds"].sum()) == 0,
        "zero_floor_violation_user_seconds": int(candidate["eligible_floor_violation_user_seconds"].sum()) == 0,
        "zero_floor_violation_user_intervals": int(candidate["eligible_floor_violation_user_intervals"].sum()) == 0,
        "strict_local_scope_all_pass": bool((candidate["candidate_strict_local_scope_gate"] == "PASS").all()),
        "strict_post_mode_power_all_pass": bool((candidate["candidate_strict_post_mode_power_gate"] == "PASS").all()),
        "zero_q0_envelope_deployable_actions": int(candidate["candidate_q0_envelope_deployable_actions"].sum()) == 0,
        "zero_unresolved_deployable_intervals": int(candidate["candidate_unresolved_deployable_intervals"].sum()) == 0,
        "zero_network_wide_shutdown_intervals": int(candidate["candidate_network_wide_shutdown_intervals"].sum()) == 0,
        "all_30_seed_results_present": len(seed_audits) == 30,
        "all_150_candidate_cells_present": len(candidate) == 150,
        "strict_post_mode_ratio_bounded": float(candidate["candidate_maximum_strict_post_mode_power_ratio"].max()) <= 1.0 + 1e-10,
    }
    all_hard = all(hard_gates.values())
    primary = bootstrap["candidate_minus_static_final_pf"]
    superiority = primary["lower_95"] > 0.0
    go = bool(all_hard and superiority)

    action_summary = {
        "baseline_noop_intervals": int(candidate["candidate_baseline_noop_intervals"].sum()),
        "local_grid_repair_intervals": int(candidate["candidate_local_grid_repair_intervals"].sum()),
        "local_stream_repair_intervals": int(candidate["candidate_local_stream_repair_intervals"].sum()),
        "maximum_mutable_sector_count": int(candidate["candidate_maximum_mutable_sector_count"].max()),
        "maximum_external_interferers_per_violating_user": int(candidate["candidate_maximum_external_interferers_per_violating_user"].max()),
        "maximum_eess_backoff_sectors": int(candidate["candidate_maximum_eess_backoff_sectors"].max()),
        "maximum_strict_post_mode_power_ratio": float(candidate["candidate_maximum_strict_post_mode_power_ratio"].max()),
        "maximum_normalized_floor_shortfall": float(candidate["candidate_maximum_normalized_floor_shortfall"].max()),
        "changed_stream_coefficient_count_sum": int(
            candidate["candidate_changed_stream_coefficient_count_sum"].sum()
        ),
        "changed_sector_interval_count_sum": int(
            candidate["candidate_changed_sector_interval_count_sum"].sum()
        ),
        "maximum_changed_stream_coefficients_per_interval": int(
            candidate[
                "candidate_maximum_changed_stream_coefficients_per_interval"
            ].max()
        ),
        "maximum_changed_sectors_per_interval": int(
            candidate["candidate_maximum_changed_sectors_per_interval"].max()
        ),
        "incremental_float32_payload_lower_bound_bytes_sum": int(
            candidate[
                "candidate_incremental_float32_payload_lower_bound_bytes_sum"
            ].sum()
        ),
        "payload_claim_boundary": (
            "FLOAT32_COEFFICIENT_VALUE_LOWER_BOUND_ONLY_EXCLUDES_IDS_HEADERS_"
            "RELIABILITY_AND_TRANSPORT_OVERHEAD"
        ),
    }
    runtime = {
        "candidate_end_to_end_seconds_sum": float(candidate["runtime_seconds"].sum()),
        "candidate_end_to_end_seconds_mean_per_pass_cell": float(candidate["runtime_seconds"].mean()),
        "candidate_local_table_build_seconds_sum": float(candidate["candidate_local_table_build_seconds_sum"].sum()),
        "candidate_repair_solver_seconds_sum": float(candidate["candidate_repair_solver_seconds_sum"].sum()),
        "candidate_local_table_build_seconds_max": float(
            candidate["candidate_local_table_build_seconds_max"].max()
        ),
        "candidate_repair_solver_seconds_max": float(
            candidate["candidate_repair_solver_seconds_max"].max()
        ),
        "candidate_repair_solver_seconds_p95_nonzero_max_across_cells": float(
            candidate["candidate_repair_solver_seconds_p95_nonzero"].max()
        ),
        "runtime_claim_boundary": (
            "SOFTWARE_RUNTIME_ON_CAMPAIGN_COMPUTE_NOT_DEPLOYMENT_LATENCY_OR_"
            "NORMALIZED_CROSS_METHOD_BENCHMARK"
        ),
        "legacy_method_runtime_comparability": "NOT_CLAIMED_METHOD_SPECIFIC_SCOPES_DIFFER",
    }
    write_json(output / "PHASE1_ACTION_AND_RUNTIME_SUMMARY.json", {
        "action_summary": action_summary,
        "runtime_summary": runtime,
        "information_exchange_locality_certified": False,
        "information_exchange_claim_boundary": campaign["information_exchange_claim_boundary"],
    })

    if go:
        status = "PASS_PHASE1_V4_3_HARD_GATES_AND_PRIMARY_SUPERIORITY_REVIEW_REQUIRED"
    elif all_hard:
        status = "VALID_PHASE1_V4_3_HARD_GATES_PASS_PRIMARY_SUPERIORITY_NOT_MET_REVIEW_REQUIRED"
    else:
        status = "VALID_PHASE1_V4_3_CANDIDATE_HARD_GATE_FAILURE_REVIEW_REQUIRED"
    summary = {
        "schema_version": 2,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "package_id": contract["package_id"],
        "candidate_source_manifest_sha256": contract["candidate_v4_3"]["source_manifest_sha256"],
        "seed_count": 30,
        "fixed_pass_count": 5,
        "method_count": 9,
        "cell_count": 1350,
        "primary_estimand": campaign["statistics"]["primary_estimand"],
        "primary_bootstrap": primary,
        "mandatory_secondary_bootstrap": bootstrap["candidate_minus_static_duration_mean_pf"],
        "repair_cost_bootstrap_final": bootstrap["candidate_minus_predictive_final_pf"],
        "repair_cost_bootstrap_duration_mean": bootstrap["candidate_minus_predictive_duration_mean_pf"],
        "hard_gates": hard_gates,
        "all_hard_gates_pass": all_hard,
        "primary_lower_95_greater_than_zero": superiority,
        "go_condition_met": go,
        "action_summary": action_summary,
        "runtime_summary": runtime,
        "information_exchange_locality_certified": False,
        "claim_scope": campaign["statistics"]["claim_scope"],
        "paper_result_boundary": "CAMPAIGN_OUTPUT_REQUIRES_INDEPENDENT_REVIEW_BEFORE_PAPER_USE",
        "campaign_execution_authorized": False,
    }
    write_json(output / "PHASE1_MERGED_AUDIT.json", summary)
    review, digest = package_output(output)
    print("PHASE1_V4_3_MERGE_AND_PREREGISTERED_ANALYSIS=COMPLETE")
    print(f"PHASE1_V4_3_MERGED_STATUS={status}")
    print(f"CANDIDATE_HARD_GATES={'PASS' if all_hard else 'FAIL'}")
    print(f"PRIMARY_LOWER_95={primary['lower_95']:.17g}")
    print(f"GO_CONDITION_MET={'YES' if go else 'NO'}")
    print(f"MERGED_REVIEW_ZIP={review}")
    print(f"MERGED_REVIEW_ZIP_SHA256={digest}")
    return 0 if all_hard else 42


if __name__ == "__main__":
    raise SystemExit(main())
